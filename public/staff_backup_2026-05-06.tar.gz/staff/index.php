<?php
require_once __DIR__ . "/../auth/core.php";

declare(strict_types=1);

require_once __DIR__ . '/../_init.php';

/**
 * AUTH + MIDDLEWARE (CORRECT PATH SOURCE)
 */
require_once PRIVATE_PATH . '/middleware/AuthMiddleware.php';

/**
 * SESSION SAFETY (only start if not started in _init.php)
 */
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * SECURITY CHECK (guarded call)
 * Avoid fatal crash if method name differs
 */
if (class_exists('AuthMiddleware') && method_exists('AuthMiddleware', 'requireStaff')) {
    AuthMiddleware::requireStaff();
}

/* ---------------------------
   FALLBACK AUTH CHECK (SAFE LAYER)
----------------------------*/
$userId = $_SESSION['user_id'] ?? 0;
$role   = $_SESSION['role'] ?? '';

if (!$userId || $role === '') {
    header('Location: /staff/login.php');
    exit;
}

/* ---------------------------
   HELPERS
----------------------------*/
function h(string $v): string {
    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

/* ---------------------------
   HEADER
----------------------------*/
require PRIVATE_PATH . '/shared/staff_header.php';
?>

<h1>Staff Dashboard</h1>

<p>Welcome, <?= h($_SESSION['email'] ?? 'staff') ?></p>

<section>
    <h2>Quick Actions</h2>
    <a href="/staff/subjects/">Subjects</a> |
    <a href="/staff/subjects/pgs/">Pages</a> |
    <a href="/staff/tools/">Tools</a> |
    <a href="/staff/audit/">Audit</a>
</section>

<section>
    <h2>Modules</h2>
    <ul>
        <li><a href="/staff/subjects/">Subjects</a></li>
        <li><a href="/staff/subjects/pgs/">Pages</a></li>
        <li><a href="/staff/contributors/">Contributors</a></li>
        <li><a href="/staff/platforms/">Platforms</a></li>
    </ul>
</section>

<section>
    <h2>Recent Tools</h2>
    <?php
    $recent_tools = $_SESSION['staff_tools_recent'] ?? [];
    if (!is_array($recent_tools)) $recent_tools = [];
    ?>

    <?php if ($recent_tools): ?>
        <ul>
            <?php foreach ($recent_tools as $t): ?>
                <li>
                    <a href="<?= h($t['url'] ?? '#') ?>">
                        <?= h($t['title'] ?? 'Tool') ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No recent tools.</p>
    <?php endif; ?>
</section>

<a href="/staff/logout.php">Logout</a>

<?php require PRIVATE_PATH . '/shared/staff_footer.php'; ?>