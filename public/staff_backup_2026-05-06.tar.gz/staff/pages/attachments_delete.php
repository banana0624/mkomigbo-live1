<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_init.php';

auth_require_role('staff');

/**
 * /public/staff/pages/attachments_delete.php
 * Staff: delete an attachment safely (DB + disk).
 *
 * Redirect: attach=deleted|missing|denied|csrf|invalid|error
 */

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);

if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'POST') { http_response_code(405); header('Allow: POST'); exit; }

if (!function_exists('staff_safe_return_url')) {
  function staff_safe_return_url(string $raw, string $default): string {
    $raw = trim($raw);
    if ($raw === '') return $default;
    $raw = rawurldecode($raw);
    if ($raw === '' || $raw[0] !== '/') return $default;
    if (preg_match('~^//~', $raw)) return $default;
    if (preg_match('~^[a-z]+:~i', $raw)) return $default;
    if (strpos($raw, '/staff/') !== 0) return $default;
    return $raw;
  }
}
if (!function_exists('staff_redirect')) {
  function staff_redirect(string $location, int $code = 302): void {
    $location = str_replace(["\r","\n"], '', $location);
    header('Location: ' . $location, true, $code);
    exit;
  }
}
if (!function_exists('staff_pdo')) {
  function staff_pdo(): ?PDO {
    return (function_exists('db') && db() instanceof PDO) ? db() : null;
  }
}
if (!function_exists('staff_csrf_verify')) {
  function staff_csrf_verify(string $token): bool {
    if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
    if ($token === '') return false;

    foreach (['csrf_verify', 'mk_csrf_verify', 'csrf_check'] as $fn) {
      if (function_exists($fn)) {
        try {
          if ($fn($token) === true) return true;
        } catch (Throwable $e) {
          // continue
        }
      }
    }

    $sessionCandidates = [];
    foreach (['csrf_token', 'csrf', '_token'] as $k) {
      if (!empty($_SESSION[$k]) && is_string($_SESSION[$k])) {
        $sessionCandidates[] = (string)$_SESSION[$k];
      }
    }
    $sessionCandidates = array_values(array_unique(array_filter($sessionCandidates, static fn($v) => $v !== '')));

    foreach ($sessionCandidates as $sess) {
      if (hash_equals($sess, $token)) return true;
    }

    return false;
  }
}
if (!function_exists('pf__column_exists')) {
  function pf__column_exists(PDO $pdo, string $table, string $column): bool {
    static $cache = [];
    $key = strtolower($table . '.' . $column);
    if (array_key_exists($key, $cache)) return (bool)$cache[$key];
    try {
      $st = $pdo->prepare("
        SELECT 1
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
          AND COLUMN_NAME = ?
        LIMIT 1
      ");
      $st->execute([$table, $column]);
      $cache[$key] = (bool)$st->fetchColumn();
      return (bool)$cache[$key];
    } catch (Throwable $e) {
      $cache[$key] = false;
      return false;
    }
  }
}

$return = staff_safe_return_url((string)($_POST['return'] ?? ''), '/staff/pages/index.php');
$go = static function (string $return, string $code): never {
  $target = $return . (strpos($return, '?') === false ? '?' : '&') . 'attach=' . rawurlencode($code);
  if (function_exists('url_for')) $target = (string)url_for($target);
  staff_redirect($target, 303);
};

$staffId = function_exists('staff_id') ? (int)staff_id() : 0;
if ($staffId < 1) $go($return, 'denied');

$token = (string)($_POST['csrf_token'] ?? ($_POST['csrf'] ?? ($_POST['_token'] ?? '')));
if (!staff_csrf_verify($token)) $go($return, 'csrf');

$id     = (int)($_POST['id'] ?? 0);
$pageId = (int)($_POST['page_id'] ?? 0);
if ($id < 1 || $pageId < 1) $go($return, 'invalid');

$pdo = staff_pdo();
if (!$pdo instanceof PDO) $go($return, 'error');

$cols = ['id','page_id'];
foreach (['file_path','stored_path','stored_name','is_external','external_url'] as $c) {
  if (pf__column_exists($pdo, 'page_files', $c)) $cols[] = $c;
}
$st = $pdo->prepare("SELECT " . implode(',', array_unique($cols)) . " FROM page_files WHERE id=:id AND page_id=:pid LIMIT 1");
$st->bindValue(':id', $id, PDO::PARAM_INT);
$st->bindValue(':pid', $pageId, PDO::PARAM_INT);
$st->execute();
$row = $st->fetch(PDO::FETCH_ASSOC) ?: null;
if (!$row) $go($return, 'missing');

$isExternal = ((int)($row['is_external'] ?? 0) === 1) || (!empty($row['external_url'] ?? ''));

$deletedFile = false;
$hadCandidate = false;

if (!$isExternal) {
  $webRoot = dirname(__DIR__, 3);
  $uploadsRoot = $webRoot . '/lib/uploads/page_files';
  $uploadsRootReal = realpath($uploadsRoot);

  if ($uploadsRootReal && is_dir($uploadsRootReal)) {
    $rootNorm = rtrim(str_replace('\\','/',$uploadsRootReal), '/');

    $relative = '';
    $storedPath = isset($row['stored_path']) ? trim((string)$row['stored_path']) : '';
    $filePath   = isset($row['file_path']) ? trim((string)$row['file_path']) : '';

    if ($storedPath !== '') $relative = $storedPath;
    elseif ($filePath !== '') $relative = $filePath;

    if ($relative !== '') {
      $abs = $relative;

      if ($abs[0] === '/' || $abs[0] === '\\') {
        $needle = '/lib/uploads/page_files/';
        $relNorm = str_replace('\\','/',$abs);
        if (strpos($relNorm, $needle) === 0) {
          $abs = $rootNorm . '/' . ltrim(substr($relNorm, strlen($needle)), '/');
        } else {
          $abs = $relNorm;
        }
      } else {
        $abs = $rootNorm . '/' . ltrim($abs, '/\\');
      }

      $hadCandidate = true;

      $real = realpath($abs);
      if ($real && is_file($real)) {
        $realNorm = str_replace('\\','/',$real);
        if (strpos($realNorm, $rootNorm . '/') === 0) {
          $deletedFile = @unlink($real) ? true : false;
        }
      }
    }
  }
}

try {
  $del = $pdo->prepare("DELETE FROM page_files WHERE id=:id AND page_id=:pid LIMIT 1");
  $del->bindValue(':id', $id, PDO::PARAM_INT);
  $del->bindValue(':pid', $pageId, PDO::PARAM_INT);
  $del->execute();
} catch (Throwable $e) {
  $go($return, 'error');
}

if ($isExternal) $go($return, 'deleted');
if (!$hadCandidate) $go($return, 'deleted');
$go($return, $deletedFile ? 'deleted' : 'missing');