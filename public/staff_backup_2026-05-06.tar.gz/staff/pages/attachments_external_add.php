<?php
declare(strict_types=1);

/**
 * /public/staff/pages/attachments_external_add.php
 * Staff: add an external attachment (allowlisted HTTPS only).
 *
 * POST:
 * - csrf_token
 * - page_id
 * - external_url
 * - label (optional)
 * - return
 *
 * Redirect: attach=saved|badurl|invalid|denied|csrf|error
 */

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);

require_once __DIR__ . '/../_init.php';
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'POST') { http_response_code(405); header('Allow: POST'); exit; }

/* ---------------------------------------------------------
   Minimal fallbacks
--------------------------------------------------------- */
if (!function_exists('staff_safe_return_url')) {
  function staff_safe_return_url(string $raw, string $default): string {
    $raw = trim($raw);
    if ($raw === '') return $default;
    $raw = rawurldecode($raw);
    if ($raw === '' || $raw[0] !== '/') return $default;
    if (preg_match('~^//~', $raw)) return $default;
    if (preg_match('~^[a-z]+:~i', $raw)) return $default;
    if (strpos($raw, '/staff/') !== 0) return $default;
    return $raw;
  }
}
if (!function_exists('staff_redirect')) {
  function staff_redirect(string $location, int $code = 302): void {
    $location = str_replace(["\r","\n"], '', $location);
    header('Location: ' . $location, true, $code);
    exit;
  }
}
if (!function_exists('staff_pdo')) {
  function staff_pdo(): ?PDO {
    return (function_exists('db') && db() instanceof PDO) ? db() : null;
  }
}
if (!function_exists('staff_csrf_verify')) {
  function staff_csrf_verify(string $token): bool {
    if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
    $sess = $_SESSION['csrf_token'] ?? '';
    if (!is_string($sess) || $sess === '' || $token === '') return false;
    return hash_equals($sess, $token);
  }
}

/* ---------------------------------------------------------
   Column-exists helper (for schema tolerance)
--------------------------------------------------------- */
if (!function_exists('pf__column_exists')) {
  function pf__column_exists(PDO $pdo, string $table, string $column): bool {
    static $cache = [];
    $key = strtolower($table . '.' . $column);
    if (array_key_exists($key, $cache)) return (bool)$cache[$key];

    try {
      $st = $pdo->prepare("
        SELECT 1
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
          AND COLUMN_NAME = ?
        LIMIT 1
      ");
      $st->execute([$table, $column]);
      $cache[$key] = (bool)$st->fetchColumn();
      return (bool)$cache[$key];
    } catch (Throwable $e) {
      $cache[$key] = false;
      return false;
    }
  }
}

$return = staff_safe_return_url((string)($_POST['return'] ?? ''), '/staff/subjects/pgs/index.php');

$go = static function (string $return, string $code): never {
  $target = $return . (strpos($return, '?') === false ? '?' : '&') . 'attach=' . rawurlencode($code);
  $target = str_replace(["\r","\n"], '', $target);
  if (function_exists('url_for')) $target = (string)url_for($target);
  staff_redirect($target, 303);
};

/* ---------------------------------------------------------
   Normalize common URL inputs (scheme-less, protocol-relative)
--------------------------------------------------------- */
$normalize = static function(string $url): string {
  $url = preg_replace('/[\x00-\x1F\x7F]/u', '', $url) ?? $url;
  $url = trim($url);
  if ($url === '') return '';

  if ($url[0] === '<' && substr($url, -1) === '>') {
    $url = trim(substr($url, 1, -1));
  }

  if (preg_match('/\s/u', $url)) {
    $parts = preg_split('/\s+/u', $url);
    if (is_array($parts) && isset($parts[0])) $url = trim((string)$parts[0]);
  }

  $url = rtrim($url, " \t\n\r\0\x0B.,;:)]}'\"");

  if (strncmp($url, '//', 2) === 0) {
    $url = 'https:' . $url;
  } elseif (!preg_match('~^[a-zA-Z][a-zA-Z0-9+\-.]*://~', $url)) {
    if ($url !== '' && ($url[0] === '/' || $url[0] === '\\')) return '';
    $url = 'https://' . $url;
  }

  return $url;
};

/* ---------------------------------------------------------
   Metadata normalization helpers (no network)
--------------------------------------------------------- */
$host_from_url = static function(string $url): string {
  $p = @parse_url($url);
  if (!is_array($p)) return '';
  $host = isset($p['host']) ? strtolower((string)$p['host']) : '';
  $host = preg_replace('/^www\./i', '', $host) ?? $host;
  $host = rtrim($host, '.');
  return $host ?: '';
};

$clean_url = static function(string $url): string {
  $p = @parse_url($url);
  if (!is_array($p) || empty($p['scheme']) || empty($p['host'])) return $url;

  $scheme = (string)$p['scheme'];
  $host   = (string)$p['host'];
  $path   = (string)($p['path'] ?? '');
  $query  = (string)($p['query'] ?? '');
  $frag   = (string)($p['fragment'] ?? '');

  // Strip common tracking parameters
  if ($query !== '') {
    parse_str($query, $q);
    if (is_array($q)) {
      foreach (array_keys($q) as $k) {
        $lk = strtolower((string)$k);
        if (str_starts_with($lk, 'utm_') || in_array($lk, ['fbclid','gclid','mc_cid','mc_eid'], true)) {
          unset($q[$k]);
        }
      }
      $query = http_build_query($q);
    }
  }

  $out = $scheme . '://' . $host . $path;
  if ($query !== '') $out .= '?' . $query;
  if ($frag !== '')  $out .= '#' . $frag;
  return $out;
};

$source_from_host = static function(string $host): array {
  $h = strtolower($host);
  $h = preg_replace('/^www\./i', '', $h) ?? $h;

  $map = [
    'wikipedia.org'      => ['wikipedia', 'Wikipedia'],
    'wikimedia.org'      => ['wikimedia', 'Wikimedia'],
    'youtu.be'           => ['youtube', 'YouTube'],
    'youtube.com'        => ['youtube', 'YouTube'],
    'archive.org'        => ['internet_archive', 'Internet Archive'],
    'openlibrary.org'    => ['openlibrary', 'Open Library'],
    'doi.org'            => ['doi', 'DOI'],
    'jstor.org'          => ['jstor', 'JSTOR'],
    'books.google.com'   => ['google_books', 'Google Books'],
    'scholar.google.com' => ['google_scholar', 'Google Scholar'],
  ];

  foreach ($map as $domain => $pair) {
    if ($h === $domain || str_ends_with($h, '.' . $domain)) return $pair;
  }

  if ($h !== '') return ['web', $h];
  return ['unknown', 'Unknown'];
};

$guess_kind_for_external = static function(string $host, string $url): string {
  $h = strtolower($host);
  if ($h === '') return 'web';

  if (preg_match('~(^|\.)youtu\.be$|(^|\.)youtube\.com$~', $h)) return 'video';
  if (preg_match('~(^|\.)wikipedia\.org$|(^|\.)wikimedia\.org$~', $h)) return 'web';
  if (preg_match('~(^|\.)archive\.org$~', $h)) return 'web';

  // URL path heuristic (lightweight)
  $p = @parse_url($url);
  $path = is_array($p) ? (string)($p['path'] ?? '') : '';
  $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
  if ($ext === 'pdf') return 'pdf';

  return 'web';
};

/* Auth */
$staffId = function_exists('staff_id') ? (int)staff_id() : 0;
if ($staffId < 1) $go($return, 'denied');

/* CSRF */
$token = (string)($_POST['csrf_token'] ?? ($_POST['csrf'] ?? ''));
if (!staff_csrf_verify($token)) $go($return, 'csrf');

/* Inputs */
$pageId = (int)($_POST['page_id'] ?? 0);
$rawUrl = (string)($_POST['external_url'] ?? '');
$label  = trim((string)($_POST['label'] ?? ''));

if ($pageId < 1) $go($return, 'invalid');

$cleanUrl = $normalize($rawUrl);
if ($cleanUrl === '') $go($return, 'invalid');

/* sanitize label */
$label = str_replace(["\r","\n"], '', $label);
if (function_exists('mb_substr')) $label = (string)mb_substr($label, 0, 255, 'UTF-8');
else $label = substr($label, 0, 255);
$label = trim($label);

/* DB */
$pdo = staff_pdo();
if (!$pdo instanceof PDO) $go($return, 'error');

/* Private authoritative validator/inserter */
if (!defined('PRIVATE_PATH') || !is_string(PRIVATE_PATH) || PRIVATE_PATH === '') $go($return, 'error');

$fn = rtrim(PRIVATE_PATH, '/\\') . '/functions/page_attachments_external.php';
if (!is_file($fn)) $go($return, 'error');
require_once $fn;

/**
 * WRITE-TIME NORMALIZATION (authoritative)
 * - validate + normalize using the same allowlist logic used everywhere else
 * - always save the normalized URL so DB is consistent (no www.* drift)
 */
if (!function_exists('mk_pagefile__validate_external_url')) $go($return, 'error');

$v = mk_pagefile__validate_external_url($cleanUrl);
if (empty($v['ok']) || empty($v['url']) || empty($v['host'])) {
  $go($return, 'badurl');
}

/* save normalized URL + authoritative host */
$cleanUrl = (string)$v['url'];
$host     = (string)$v['host'];

/* Insert via canonical helper */
if (!function_exists('mk_staff_add_external_page_attachment')) $go($return, 'error');

try {
  $res = mk_staff_add_external_page_attachment($pdo, $pageId, $staffId, $cleanUrl, $label);

  if (!is_array($res) || empty($res['ok'])) {
    $err = strtolower(trim((string)($res['error'] ?? '')));
    if ($err !== '' && (
      (function_exists('str_contains') && (
        str_contains($err, 'allow') ||
        str_contains($err, 'https') ||
        str_contains($err, 'host') ||
        str_contains($err, 'path') ||
        str_contains($err, 'url')
      ))
    )) {
      $go($return, 'badurl');
    }
    $go($return, 'error');
  }

  /* ---------------------------------------------------------
     INSERT-TIME METADATA BACKFILL (idempotent, schema-tolerant)
     Only fills empty fields; never overwrites staff-edited values.
  --------------------------------------------------------- */
  $fileId = 0;

  // Try common keys from helper result
  foreach (['file_id','id','page_file_id','insert_id'] as $k) {
    if (isset($res[$k]) && is_numeric($res[$k])) { $fileId = (int)$res[$k]; break; }
  }

  // Fallback: PDO lastInsertId (works for typical single-row insert)
  if ($fileId < 1) {
    try {
      $lid = (string)$pdo->lastInsertId();
      if ($lid !== '' && ctype_digit($lid)) $fileId = (int)$lid;
    } catch (Throwable $e) { $fileId = 0; }
  }

  if ($fileId > 0) {
    $has_kind      = pf__column_exists($pdo, 'page_files', 'kind');
    $has_sourcekey = pf__column_exists($pdo, 'page_files', 'source_key');
    $has_sourcelab = pf__column_exists($pdo, 'page_files', 'source_label');
    $has_host      = pf__column_exists($pdo, 'page_files', 'host');
    $has_canon     = pf__column_exists($pdo, 'page_files', 'canonical_url');
    $has_title     = pf__column_exists($pdo, 'page_files', 'title');

    // Read current row (so we only fill empties)
    $want = ['id','page_id','is_external','external_url','external_host','original_name'];
    if ($has_kind)      $want[] = 'kind';
    if ($has_sourcekey) $want[] = 'source_key';
    if ($has_sourcelab) $want[] = 'source_label';
    if ($has_host)      $want[] = 'host';
    if ($has_canon)     $want[] = 'canonical_url';
    if ($has_title)     $want[] = 'title';

    $stR = $pdo->prepare("SELECT " . implode(',', $want) . " FROM page_files WHERE id = :id AND page_id = :pid LIMIT 1");
    $stR->execute([':id' => $fileId, ':pid' => $pageId]);
    $row = $stR->fetch(PDO::FETCH_ASSOC) ?: null;

    if ($row) {
      $curHost  = trim((string)($row['host'] ?? ''));
      $curCanon = trim((string)($row['canonical_url'] ?? ''));
      $curKind  = trim((string)($row['kind'] ?? ''));
      $curSk    = trim((string)($row['source_key'] ?? ''));
      $curSl    = trim((string)($row['source_label'] ?? ''));
      $curTitle = trim((string)($row['title'] ?? ''));

      $calcHost  = $curHost !== '' ? $curHost : ($host !== '' ? $host : $host_from_url($cleanUrl));
      $calcCanon = $curCanon !== '' ? $curCanon : $clean_url($cleanUrl);
      $calcKind  = $curKind !== '' ? $curKind : $guess_kind_for_external($calcHost, $cleanUrl);

      [$calcSk, $calcSl] = $source_from_host($calcHost);

      // Prefer label as "original_name" semantics, but only if title is empty and you actually have title column
      $calcTitle = $curTitle;
      if ($has_title && $calcTitle === '') {
        if ($label !== '') $calcTitle = $label;
        elseif (!empty($row['original_name'])) $calcTitle = (string)$row['original_name'];
        elseif ($calcSl !== '') $calcTitle = $calcSl;
      }

      $sets = [];
      $bind = [':id' => $fileId, ':pid' => $pageId];

      if ($has_host && $curHost === '' && $calcHost !== '') { $sets[] = "host = :h"; $bind[':h'] = $calcHost; }
      if ($has_canon && $curCanon === '' && $calcCanon !== '') { $sets[] = "canonical_url = :cu"; $bind[':cu'] = $calcCanon; }
      if ($has_kind && $curKind === '' && $calcKind !== '') { $sets[] = "kind = :k"; $bind[':k'] = $calcKind; }

      if ($has_sourcekey && $curSk === '' && $calcSk !== '') { $sets[] = "source_key = :sk"; $bind[':sk'] = $calcSk; }
      if ($has_sourcelab && $curSl === '' && $calcSl !== '') { $sets[] = "source_label = :sl"; $bind[':sl'] = $calcSl; }

      if ($has_title && $curTitle === '' && $calcTitle !== '') { $sets[] = "title = :t"; $bind[':t'] = $calcTitle; }

      if ($sets) {
        $sqlU = "UPDATE page_files SET " . implode(', ', $sets) . " WHERE id = :id AND page_id = :pid LIMIT 1";
        $stU = $pdo->prepare($sqlU);
        foreach ($bind as $k => $v) {
          if ($v === null) $stU->bindValue($k, null, PDO::PARAM_NULL);
          elseif (is_int($v)) $stU->bindValue($k, $v, PDO::PARAM_INT);
          else $stU->bindValue($k, (string)$v, PDO::PARAM_STR);
        }
        $stU->execute();
      }
    }
  }

  $go($return, 'saved');
} catch (Throwable $e) {
  $go($return, 'error');
}
