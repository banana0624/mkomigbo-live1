<?php
declare(strict_types=1);

/**
 * /public/staff/pages/attachments_upload.php
 * Staff: upload page attachments
 *
 * Redirect: attach=sent|partial|error|invalid|csrf|too_large|nofile
 */

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);

require_once __DIR__ . '/../_init.php';
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'POST') {
  http_response_code(405);
  header('Allow: POST');
  exit;
}

/* ---------------------------------------------------------
   Minimal fallbacks (only if _init.php did not provide them)
--------------------------------------------------------- */
if (!function_exists('staff_safe_return_url')) {
  function staff_safe_return_url(string $raw, string $default): string {
    $raw = trim($raw);
    if ($raw === '') return $default;
    $raw = rawurldecode($raw);
    if ($raw === '' || $raw[0] !== '/') return $default;
    if (preg_match('~^//~', $raw)) return $default;
    if (preg_match('~^[a-z]+:~i', $raw)) return $default;
    if (strpos($raw, '/staff/') !== 0) return $default;
    return $raw;
  }
}
if (!function_exists('staff_redirect')) {
  function staff_redirect(string $location, int $code = 302): void {
    $location = str_replace(["\r","\n"], '', $location);
    header('Location: ' . $location, true, $code);
    exit;
  }
}
if (!function_exists('staff_pdo')) {
  function staff_pdo(): ?PDO {
    return (function_exists('db') && db() instanceof PDO) ? db() : null;
  }
}
if (!function_exists('staff_csrf_verify')) {
  function staff_csrf_verify(string $token): bool {
    if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
    $sess = $_SESSION['csrf_token'] ?? '';
    if (!is_string($sess) || $sess === '' || $token === '') return false;
    return hash_equals($sess, $token);
  }
}

/* ---------------------------------------------------------
   Column-exists helper (schema tolerant)
--------------------------------------------------------- */
if (!function_exists('pf__column_exists')) {
  function pf__column_exists(PDO $pdo, string $table, string $column): bool {
    static $cache = [];
    $key = strtolower($table . '.' . $column);
    if (array_key_exists($key, $cache)) return (bool)$cache[$key];

    try {
      $st = $pdo->prepare("
        SELECT 1
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
          AND COLUMN_NAME = ?
        LIMIT 1
      ");
      $st->execute([$table, $column]);
      $cache[$key] = (bool)$st->fetchColumn();
      return (bool)$cache[$key];
    } catch (Throwable $e) {
      $cache[$key] = false;
      return false;
    }
  }
}

$return = staff_safe_return_url((string)($_POST['return'] ?? ''), '/staff/subjects/pgs/index.php');

/* redirect helper: attaches attach=... to return URL */
$go = static function (string $return, string $code): never {
  $target = $return . (strpos($return, '?') === false ? '?' : '&') . 'attach=' . rawurlencode($code);
  $target = str_replace(["\r","\n"], '', $target);
  if (function_exists('url_for')) $target = (string)url_for($target);
  staff_redirect($target, 303);
};

/* Require login */
$staffId = function_exists('staff_id') ? (int)staff_id() : 0;
if ($staffId < 1) {
  $login = function_exists('url_for')
    ? (string)url_for('/staff/login.php?notice=login')
    : '/staff/login.php?notice=login';
  $login = str_replace(["\r","\n"], '', $login);
  header('Location: ' . $login, true, 302);
  exit;
}

/* CSRF (accept csrf_token canonical + legacy csrf) */
$token = (string)($_POST['csrf_token'] ?? ($_POST['csrf'] ?? ''));
if (!staff_csrf_verify($token)) {
  $go($return, 'csrf');
}

/* Validate page_id */
$pageId = (int)($_POST['page_id'] ?? 0);
if ($pageId < 1) {
  $go($return, 'invalid');
}

/* Detect “POST too large” (PHP drops $_POST/$_FILES silently) */
$cl = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($cl > 0 && empty($_FILES)) {
  $go($return, 'too_large');
}

/* Validate files exist */
$files = $_FILES['attachments'] ?? null;
if (!is_array($files) || (!isset($files['name']) && !isset($files['tmp_name']))) {
  $go($return, 'nofile');
}

/* DB */
$pdo = staff_pdo();
if (!$pdo instanceof PDO) {
  $go($return, 'error');
}

/* Delegate to private, authoritative upload engine */
if (!defined('PRIVATE_PATH') || !is_string(PRIVATE_PATH) || PRIVATE_PATH === '') {
  $go($return, 'error');
}

$fn = rtrim(PRIVATE_PATH, '/\\') . '/functions/page_attachments_upload.php';
if (!is_file($fn)) {
  $go($return, 'error');
}
require_once $fn;

if (!function_exists('mk_staff_upload_page_attachments')) {
  $go($return, 'error');
}

/* ---------------------------------------------------------
   Local metadata normalizer (no network)
--------------------------------------------------------- */
$guess_kind_local = static function(string $mime, string $nameOrPath): string {
  $m = strtolower(trim($mime));
  if ($m !== '') {
    if (str_starts_with($m, 'application/pdf')) return 'pdf';
    if (str_starts_with($m, 'image/')) return 'image';
    if (str_starts_with($m, 'audio/')) return 'audio';
    if (str_starts_with($m, 'video/')) return 'video';
    if (preg_match('~(text/plain|text/markdown|text/html)~', $m)) return 'doc';
  }

  $ext = strtolower(pathinfo($nameOrPath, PATHINFO_EXTENSION));
  if ($ext === 'pdf') return 'pdf';
  if (in_array($ext, ['png','jpg','jpeg','gif','webp','svg'], true)) return 'image';
  if (in_array($ext, ['mp3','wav','ogg','m4a','flac'], true)) return 'audio';
  if (in_array($ext, ['mp4','webm','mov','mkv'], true)) return 'video';
  if (in_array($ext, ['csv','tsv','json','xml'], true)) return 'dataset';
  if (in_array($ext, ['doc','docx','rtf','txt','md','html','htm','ppt','pptx','xls','xlsx'], true)) return 'doc';

  return 'other';
};

try {
  $res = mk_staff_upload_page_attachments($pdo, $pageId, $staffId, $files);

  $notice = 'sent';
  if (!is_array($res) || empty($res['ok'])) $notice = 'error';
  if (is_array($res) && !empty($res['errors'])) $notice = 'partial';

  /* ---------------------------------------------------------
     INSERT-TIME METADATA BACKFILL (local uploads)
     - only fills empty fields
     - schema-tolerant
     - tries to use returned IDs; falls back to "recent rows"
  --------------------------------------------------------- */
  if ($notice !== 'error') {
    $has_kind      = pf__column_exists($pdo, 'page_files', 'kind');
    $has_sourcekey = pf__column_exists($pdo, 'page_files', 'source_key');
    $has_sourcelab = pf__column_exists($pdo, 'page_files', 'source_label');
    $has_host      = pf__column_exists($pdo, 'page_files', 'host');
    $has_canon     = pf__column_exists($pdo, 'page_files', 'canonical_url');
    $has_title     = pf__column_exists($pdo, 'page_files', 'title');

    // If none of the new columns exist, skip quietly
    if ($has_kind || $has_sourcekey || $has_sourcelab || $has_host || $has_canon || $has_title) {

      // 1) Collect candidate inserted IDs from $res (best case)
      $ids = [];

      $pull_ids = static function($v) use (&$ids): void {
        if (is_numeric($v)) { $ids[] = (int)$v; return; }
        if (is_string($v) && ctype_digit($v)) { $ids[] = (int)$v; return; }
        if (is_array($v)) {
          foreach ($v as $x) {
            if (is_numeric($x)) $ids[] = (int)$x;
            elseif (is_string($x) && ctype_digit($x)) $ids[] = (int)$x;
          }
        }
      };

      if (is_array($res)) {
        foreach (['ids','file_ids','page_file_ids','insert_ids'] as $k) {
          if (array_key_exists($k, $res)) $pull_ids($res[$k]);
        }
        // some uploaders return per-file arrays
        foreach (['files','uploaded','saved'] as $k) {
          if (!array_key_exists($k, $res) || !is_array($res[$k])) continue;
          foreach ($res[$k] as $row) {
            if (!is_array($row)) continue;
            foreach (['id','file_id','page_file_id'] as $kk) {
              if (isset($row[$kk])) $pull_ids($row[$kk]);
            }
          }
        }
      }

      // de-dupe
      $ids = array_values(array_unique(array_filter($ids, static fn($n) => is_int($n) && $n > 0)));

      // 2) If uploader didn’t return IDs, fall back to recent local rows for this page
      $rows = [];
      if ($ids) {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $sql = "
          SELECT id, page_id, is_external, original_name, stored_name, file_path, stored_path, mime_type, file_size, created_at
          " . ($has_kind ? ", kind" : "") . "
          " . ($has_sourcekey ? ", source_key" : "") . "
          " . ($has_sourcelab ? ", source_label" : "") . "
          " . ($has_host ? ", host" : "") . "
          " . ($has_canon ? ", canonical_url" : "") . "
          " . ($has_title ? ", title" : "") . "
          FROM page_files
          WHERE page_id = ?
            AND id IN ($in)
          ORDER BY id DESC
        ";
        $st = $pdo->prepare($sql);
        $st->execute(array_merge([$pageId], $ids));
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
      } else {
        // "recent" heuristic: last 25 for that page, local only
        $sql = "
          SELECT id, page_id, is_external, original_name, stored_name, file_path, stored_path, mime_type, file_size, created_at
          " . ($has_kind ? ", kind" : "") . "
          " . ($has_sourcekey ? ", source_key" : "") . "
          " . ($has_sourcelab ? ", source_label" : "") . "
          " . ($has_host ? ", host" : "") . "
          " . ($has_canon ? ", canonical_url" : "") . "
          " . ($has_title ? ", title" : "") . "
          FROM page_files
          WHERE page_id = ?
            AND (is_external IS NULL OR is_external = 0)
          ORDER BY id DESC
          LIMIT 25
        ";
        $st = $pdo->prepare($sql);
        $st->execute([$pageId]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
      }

      foreach ($rows as $r) {
        $id = (int)($r['id'] ?? 0);
        if ($id < 1) continue;

        // local only
        $isExt = (int)($r['is_external'] ?? 0) === 1;
        if ($isExt) continue;

        $curKind  = trim((string)($r['kind'] ?? ''));
        $curSk    = trim((string)($r['source_key'] ?? ''));
        $curSl    = trim((string)($r['source_label'] ?? ''));
        $curHost  = trim((string)($r['host'] ?? ''));
        $curCanon = trim((string)($r['canonical_url'] ?? ''));
        $curTitle = trim((string)($r['title'] ?? ''));

        $mime = (string)($r['mime_type'] ?? '');
        $nameHint = (string)($r['original_name'] ?? '');
        if ($nameHint === '') $nameHint = (string)($r['stored_name'] ?? '');
        if ($nameHint === '') $nameHint = (string)($r['file_path'] ?? '');
        if ($nameHint === '') $nameHint = (string)($r['stored_path'] ?? '');

        $calcKind = ($curKind !== '') ? $curKind : $guess_kind_local($mime, $nameHint);

        // For local uploads: set source to Local (if columns exist and empty)
        $calcSk = ($curSk !== '') ? $curSk : 'local';
        $calcSl = ($curSl !== '') ? $curSl : 'Local';

        // host/canonical_url: leave NULL for local (unless you later want to store local canonical paths)
        $sets = [];
        $bind = [':id' => $id, ':pid' => $pageId];

        if ($has_kind && $curKind === '' && $calcKind !== '') { $sets[] = "kind = :k"; $bind[':k'] = $calcKind; }
        if ($has_sourcekey && $curSk === '' && $calcSk !== '') { $sets[] = "source_key = :sk"; $bind[':sk'] = $calcSk; }
        if ($has_sourcelab && $curSl === '' && $calcSl !== '') { $sets[] = "source_label = :sl"; $bind[':sl'] = $calcSl; }

        // Optional: title from original_name (only if empty)
        if ($has_title && $curTitle === '') {
          $t = trim((string)($r['original_name'] ?? ''));
          if ($t === '') $t = trim((string)($r['stored_name'] ?? ''));
          if ($t !== '') { $sets[] = "title = :t"; $bind[':t'] = $t; }
        }

        // Never write host/canonical_url for local uploads here (keep null)
        // But if you want to force-null them (cleanup), you can add it later.

        if ($sets) {
          $sqlU = "UPDATE page_files SET " . implode(', ', $sets) . " WHERE id = :id AND page_id = :pid LIMIT 1";
          $stU = $pdo->prepare($sqlU);
          foreach ($bind as $k => $v) {
            if ($v === null) $stU->bindValue($k, null, PDO::PARAM_NULL);
            elseif (is_int($v)) $stU->bindValue($k, $v, PDO::PARAM_INT);
            else $stU->bindValue($k, (string)$v, PDO::PARAM_STR);
          }
          $stU->execute();
        }
      }
    }
  }

  $go($return, $notice);
} catch (Throwable $e) {
  $go($return, 'error');
}
