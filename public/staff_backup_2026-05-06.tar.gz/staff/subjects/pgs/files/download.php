<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../../_init.php';

/**
 * /public/staff/subjects/pgs/files/download.php
 * Legacy GET shim -> POST /staff/page-files/download.php
 *
 * Purpose:
 * - Preserve legacy GET download links
 * - Funnel into canonical POST+CSRF endpoint that streams from uploads root
 *
 * GET:
 *   id        (page_files.id) required
 *   page_id   (pages.id)      required
 */

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
if (!function_exists('h')) {
  function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
}

/* Staff auth */
auth_require_role('staff');

/* Inputs */
$fileId = (int)($_GET['id'] ?? 0);
$pageId = (int)($_GET['page_id'] ?? 0);

if ($fileId < 1 || $pageId < 1) {
  http_response_code(400);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Invalid download request.\n";
  exit;
}

/* Ensure CSRF token exists */
if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* Canonical POST endpoint */
$action = function_exists('url_for') ? (string)url_for('/staff/page-files/download.php') : '/staff/page-files/download.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Downloading…</title>
</head>
<body>
  <p style="font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial; padding:12px;">
    Preparing download…
  </p>

  <form id="dl" method="post" action="<?php echo h($action); ?>" target="_self">
    <input type="hidden" name="csrf_token" value="<?php echo h((string)$_SESSION['csrf_token']); ?>">
    <input type="hidden" name="file_id" value="<?php echo (int)$fileId; ?>">
    <input type="hidden" name="page_id" value="<?php echo (int)$pageId; ?>">

    <noscript>
      <p style="font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial; padding:12px;">
        JavaScript is disabled. Click to continue:
      </p>
      <button type="submit">Download</button>
    </noscript>
  </form>

  <script>
    (function () {
      var f = document.getElementById('dl');
      if (f) f.submit();
    })();
  </script>
</body>
</html>
