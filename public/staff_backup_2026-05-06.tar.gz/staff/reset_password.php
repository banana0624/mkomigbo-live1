<?php
require_once __DIR__ . "/../auth/core.php";
declare(strict_types=1);

require_once __DIR__ . '/../_init.php';

/**
 * /public/staff/reset_password.php
 * Admin-only staff password reset tool (tight mode):
 * - Requires current admin password
 * - Requires typing "RESET" to confirm
 * - Dropdown of staff users (active + inactive labeled)
 * - Strong password generator button
 * - DB audit log via mk_staff_audit_log() when available
 */

if (!ob_get_level()) { @ob_start(); }
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

////////////////////////////////////////////////////////////
// Helpers
////////////////////////////////////////////////////////////
function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }

function staff_log(string $msg): void {
  $paths = [__DIR__ . '/staff_login_debug.log', '/tmp/staff_login_debug.log'];
  foreach ($paths as $p) {
    if (@file_put_contents($p, date('c')." ".$msg."\n", FILE_APPEND)) break;
  }
}

////////////////////////////////////////////////////////////
// Ensure auth helpers exist (same as staff/index.php)
////////////////////////////////////////////////////////////
if (!function_exists('mk_require_staff_login')) {
  $auth = null;
  if (defined('PRIVATE_PATH') && is_string(PRIVATE_PATH) && PRIVATE_PATH !== '') {
    $auth = PRIVATE_PATH . '/functions/auth.php';
  } elseif (defined('APP_ROOT') && is_string(APP_ROOT) && APP_ROOT !== '') {
    $auth = rtrim(APP_ROOT, "/\\") . '/private/functions/auth.php';
  }
  if ($auth && is_file($auth)) require_once $auth;
}

if (function_exists('mk_require_staff_login')) {
  auth_require_role('staff');
} else {
  header('Location: /staff/login.php', true, 302);
  exit;
}

////////////////////////////////////////////////////////////
// Identify current staff (robust)
////////////////////////////////////////////////////////////
$staff_id = 0;
$staff_role = '';

foreach (['staff_user_id','staff_id'] as $k) {
  if (!empty($_SESSION[$k]) && is_numeric($_SESSION[$k])) { $staff_id = (int)$_SESSION[$k]; break; }
}
foreach (['staff_role','role'] as $k) {
  if (!empty($_SESSION[$k]) && is_string($_SESSION[$k])) { $staff_role = (string)$_SESSION[$k]; break; }
}
if ($staff_id <= 0 && !empty($_SESSION['staff_user']) && is_array($_SESSION['staff_user']) && is_numeric($_SESSION['staff_user']['id'] ?? null)) {
  $staff_id = (int)$_SESSION['staff_user']['id'];
}
if ($staff_role === '' && !empty($_SESSION['staff_user']) && is_array($_SESSION['staff_user']) && is_string($_SESSION['staff_user']['role'] ?? null)) {
  $staff_role = (string)$_SESSION['staff_user']['role'];
}

if ($staff_id <= 0) {
  staff_log("pwreset_denied_unknown_session sid=".session_id());
  header('Location: /staff/login.php', true, 302);
  exit;
}

if ($staff_role !== 'admin') {
  staff_log("pwreset_denied_not_admin staff_id={$staff_id} role=".($staff_role ?: ''));
  http_response_code(403);
  echo "Forbidden";
  exit;
}

////////////////////////////////////////////////////////////
// CSRF
////////////////////////////////////////////////////////////
function csrf_token(): string {
  if (empty($_SESSION['staff_csrf'])) $_SESSION['staff_csrf'] = bin2hex(random_bytes(32));
  return $_SESSION['staff_csrf'];
}
function csrf_valid(?string $token): bool {
  return $token && !empty($_SESSION['staff_csrf']) && hash_equals((string)$_SESSION['staff_csrf'], (string)$token);
}

////////////////////////////////////////////////////////////
// Fetch staff dropdown
////////////////////////////////////////////////////////////
$staff_list = [];
try {
  $pdo = db();
  $q = $pdo->query("SELECT id, email, role, is_active FROM staff_users ORDER BY is_active DESC, role ASC, email ASC LIMIT 500");
  $staff_list = $q ? $q->fetchAll(PDO::FETCH_ASSOC) : [];
} catch (Throwable $e) {
  staff_log("pwreset_stafflist_err ".$e->getMessage());
}

////////////////////////////////////////////////////////////
// POST handler
////////////////////////////////////////////////////////////
$ok = false;
$error = '';
$msg = '';

$target_id = 0;
$target_email = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
  $csrf = (string)($_POST['csrf'] ?? '');
  $admin_current_pass = (string)($_POST['admin_current_password'] ?? '');
  $confirm = trim((string)($_POST['confirm_reset'] ?? ''));

  $target_id = (int)($_POST['target_staff_id'] ?? 0);
  $target_email = trim((string)($_POST['email'] ?? '')); // optional manual override

  $new1 = (string)($_POST['new_password'] ?? '');
  $new2 = (string)($_POST['new_password2'] ?? '');

  if (!csrf_valid($csrf)) {
    $error = "Security validation failed (CSRF).";
    staff_log("pwreset_csrf_fail admin={$staff_id}");
  } elseif ($admin_current_pass === '') {
    $error = "Enter your current admin password to proceed.";
  } elseif (strcasecmp($confirm, 'RESET') !== 0) {
    $error = 'Confirmation required. Type RESET to confirm.';
  } elseif ($target_id <= 0 && $target_email === '') {
    $error = "Select a staff user (or enter email).";
  } elseif ($new1 === '' || $new2 === '') {
    $error = "New password fields are required.";
  } elseif ($new1 !== $new2) {
    $error = "Passwords do not match.";
  } elseif (strlen($new1) < 12) {
    $error = "Password too short (min 12 characters).";
  } else {

    try {
      $pdo = db();

      // Verify admin current password from DB
      $stA = $pdo->prepare("SELECT id,email,password_hash,role,is_active FROM staff_users WHERE id=? LIMIT 1");
      $stA->execute([$staff_id]);
      $admin = $stA->fetch(PDO::FETCH_ASSOC);

      if (!$admin || !(bool)$admin['is_active']) {
        $error = "Admin account not found or inactive.";
        staff_log("pwreset_admin_missing admin={$staff_id}");
      } elseif (($admin['role'] ?? '') !== 'admin') {
        $error = "Forbidden (admin only).";
        staff_log("pwreset_admin_role_mismatch admin={$staff_id} role=".($admin['role'] ?? ''));
      } elseif (!password_verify($admin_current_pass, (string)($admin['password_hash'] ?? ''))) {
        $error = "Current admin password is incorrect.";
        staff_log("pwreset_admin_badpass admin={$staff_id}");
        if (function_exists('mk_staff_audit_log')) { mk_staff_audit_log('staff_pwreset_denied_bad_admin_pass'); }
      } else {

        // Locate target
        $u = null;
        if ($target_id > 0) {
          $stT = $pdo->prepare("SELECT id,email,role,is_active FROM staff_users WHERE id=? LIMIT 1");
          $stT->execute([$target_id]);
          $u = $stT->fetch(PDO::FETCH_ASSOC);
        } else {
          $stT = $pdo->prepare("SELECT id,email,role,is_active FROM staff_users WHERE LOWER(email)=LOWER(?) LIMIT 1");
          $stT->execute([$target_email]);
          $u = $stT->fetch(PDO::FETCH_ASSOC);
        }

        if (!$u) {
          $error = "No staff user found.";
        } else {
          $hash = password_hash($new1, PASSWORD_DEFAULT);

          $up = $pdo->prepare("UPDATE staff_users SET password_hash=? WHERE id=? LIMIT 1");
          $up->execute([$hash, (int)$u['id']]);

          $ok = true;
          $msg = "Password reset successfully for ".$u['email'].".";
          staff_log("pwreset_ok admin={$staff_id} target_id={$u['id']} role={$u['role']} active={$u['is_active']}");

          if (function_exists('mk_staff_audit_log')) {
              mk_staff_audit_log('staff_password_reset', [
                'target_staff_user_id' => (int)$u['id'],
                'target_email' => (string)$u['email'],
                'target_role' => (string)($u['role'] ?? ''),
                'target_is_active' => (int)($u['is_active'] ?? 0),
              ], $staff_id);
            }

          unset($_SESSION['staff_csrf']); // rotate CSRF
        }
      }
    } catch (Throwable $e) {
      $error = "Password reset failed.";
      staff_log("pwreset_db_error admin={$staff_id} err=".$e->getMessage());
    }
  }
}

$csrf = csrf_token();

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reset Staff Password</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f6f7f9;margin:0;padding:24px}
.card{max-width:720px;margin:0 auto;background:#fff;padding:22px;border-radius:10px;box-shadow:0 4px 14px rgba(0,0,0,.08)}
h1{margin:0 0 12px 0;font-size:20px}
label{display:block;margin-top:12px;font-size:14px}
input,select{width:100%;padding:10px;margin-top:6px;border:1px solid #cfd4dc;border-radius:6px}
button{margin-top:16px;padding:10px 12px;border:none;border-radius:6px;background:#2563eb;color:#fff;font-size:14px;cursor:pointer}
.btn2{background:#111827}
.err{color:#b00020;font-size:14px;margin:10px 0}
.ok{color:#0a7a2f;font-size:14px;margin:10px 0}
.row{display:flex;gap:12px}
.row>div{flex:1}
.toplinks{display:flex;gap:10px;margin-bottom:12px}
a{color:#2563eb;text-decoration:none} a:hover{text-decoration:underline}
.small{color:#555;font-size:13px;line-height:1.35;margin-top:10px}
code{background:#f0f2f5;padding:2px 6px;border-radius:6px}
.hr{height:1px;background:#eef0f3;margin:14px 0}
</style>
</head>
<body>

<div class="card">
  <div class="toplinks">
    <a href="/staff/">← Staff Home</a>
    <a href="/staff/logout.php">Logout</a>
  </div>

  <h1>Reset Staff Password (Admin)</h1>

  <?php if ($error): ?><div class="err"><?=h($error)?></div><?php endif; ?>
  <?php if ($ok): ?><div class="ok"><?=h($msg ?: 'Done.')?></div><?php endif; ?>

  <form method="post" autocomplete="off">
    <input type="hidden" name="csrf" value="<?=h($csrf)?>">

    <label>Your current admin password (required)</label>
    <input type="password" name="admin_current_password" required>

    <div class="hr"></div>

    <label>Select staff user</label>
    <select name="target_staff_id">
      <option value="0">-- Select staff --</option>
      <?php foreach ($staff_list as $u): ?>
        <?php
          $id = (int)($u['id'] ?? 0);
          $email = (string)($u['email'] ?? '');
          $role = (string)($u['role'] ?? '');
          $act = (int)($u['is_active'] ?? 0);
          $label = $email . "  [" . ($role ?: '-') . "]" . ($act ? "" : "  (INACTIVE)");
          $sel = ($target_id === $id) ? 'selected' : '';
        ?>
        <option value="<?=h((string)$id)?>" <?=$sel?>><?=h($label)?></option>
      <?php endforeach; ?>
    </select>

    <div class="small">Or manually enter email (optional override)</div>
    <input type="email" name="email" value="<?=h($target_email)?>" placeholder="staff@example.com">

    <div class="row">
      <div>
        <label>New password</label>
        <input id="pw1" type="text" name="new_password" required>
      </div>
      <div>
        <label>Confirm new password</label>
        <input id="pw2" type="text" name="new_password2" required>
      </div>
    </div>

    <div class="row">
      <div>
        <label>Type RESET to confirm</label>
        <input type="text" name="confirm_reset" placeholder="RESET" required>
      </div>
      <div style="display:flex;align-items:flex-end;gap:10px">
        <button class="btn2" type="button" onclick="mkGenPw()">Generate strong password</button>
      </div>
    </div>

    <button type="submit">Reset Password</button>

    <div class="small">
      Logged in as staff_id <code><?=h((string)$staff_id)?></code>, role <code><?=h($staff_role)?></code>.
      Password min length: <code>12</code>.
    </div>
  </form>
</div>

<script>
function mkGenPw(){
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_=+?";
  const len = 16;
  let out = "";
  const a = new Uint32Array(len);
  (window.crypto || window.msCrypto).getRandomValues(a);
  for (let i=0;i<len;i++){
    out += chars[a[i] % chars.length];
  }
  const p1 = document.getElementById("pw1");
  const p2 = document.getElementById("pw2");
  if (p1) p1.value = out;
  if (p2) p2.value = out;
}
</script>

</body>
</html>