<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_init.php';

/**
 * /public/staff/page-files/download.php
 *
 * Staff open/download attachment:
 * - Local: streams file from /public_html/lib/uploads/page_files/{page_id}/...
 * - External: re-validates URL via allowlist and 302 redirects (never fetches)
 *
 * POST-only + CSRF required.
 */

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'POST') { http_response_code(405); header('Allow: POST'); exit; }

if (function_exists('mk_staff_session_start')) {
  mk_staff_session_start();
} elseif (function_exists('mk__session_start')) {
  mk__session_start();
} elseif (session_status() !== PHP_SESSION_ACTIVE) {
  @session_start();
}

auth_require_role('staff');

if (!function_exists('h')) {
  function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('staff_csrf_verify')) {
  function staff_csrf_verify(string $token): bool {
$sess = $_SESSION['csrf_token'] ?? '';
    if (!is_string($sess) || $sess === '' || $token === '') return false;
    return hash_equals($sess, $token);
  }
}

if (!function_exists('mk_staff_audit_try')) {
  function mk_staff_audit_try(PDO $pdo, string $action, array $meta = []): void {
    try {
      $st = $pdo->prepare("
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'staff_audit_log'
        LIMIT 1
      ");
      $st->execute();
      if (!$st->fetchColumn()) return;

      $user = $_SESSION['staff_email'] ?? ($_SESSION['email'] ?? ($_SESSION['user_email'] ?? ''));
      if (!is_string($user)) $user = '';

      $ip  = (string)($_SERVER['REMOTE_ADDR'] ?? '');
      $ua  = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
      $js  = json_encode($meta, JSON_UNESCAPED_SLASHES);

      $ins = $pdo->prepare("
        INSERT INTO staff_audit_log (action, actor, ip, user_agent, meta_json, created_at)
        VALUES (:action, :actor, :ip, :ua, :meta, NOW())
      ");
      $ins->execute([
        ':action' => $action,
        ':actor'  => $user,
        ':ip'     => $ip,
        ':ua'     => $ua,
        ':meta'   => is_string($js) ? $js : '{}',
      ]);
    } catch (Throwable $e) {}
  }
}

$token = (string)($_POST['csrf_token'] ?? '');
if (!staff_csrf_verify($token)) {
  http_response_code(403);
  header('Content-Type: text/plain; charset=utf-8');
  echo "CSRF failed.\n";
  exit;
}

/* Inputs */
$fileId = (int)($_POST['file_id'] ?? 0);
$pageId = (int)($_POST['page_id'] ?? 0);
if ($fileId < 1 || $pageId < 1) {
  http_response_code(400);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Invalid request.\n";
  exit;
}

/* DB */
$pdo = (function_exists('db') && db() instanceof PDO) ? db() : null;
if (!$pdo instanceof PDO) {
  http_response_code(500);
  header('Content-Type: text/plain; charset=utf-8');
  echo "DB not available.\n";
  exit;
}

/* Fetch row (must belong to this page_id) */
$cols = ['id','page_id','original_name','stored_name','file_path','stored_path','mime_type','file_size','created_at'];
foreach (['is_external','external_url','external_host'] as $c) {
  try {
    $stc = $pdo->prepare("
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='page_files' AND COLUMN_NAME=?
      LIMIT 1
    ");
    $stc->execute([$c]);
    if ($stc->fetchColumn()) $cols[] = $c;
  } catch (Throwable $e) {}
}

$st = $pdo->prepare("
  SELECT " . implode(',', array_unique($cols)) . "
  FROM page_files
  WHERE id = :id AND page_id = :pid
  LIMIT 1
");
$st->execute([':id' => $fileId, ':pid' => $pageId]);
$row = $st->fetch(PDO::FETCH_ASSOC) ?: null;

if (!$row) {
  http_response_code(404);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Attachment not found.\n";
  exit;
}

$isExternal = !empty($row['is_external'] ?? 0);
$extUrl = trim((string)($row['external_url'] ?? ''));

if ($isExternal) {
  if ($extUrl === '') {
    http_response_code(400);
    header('Content-Type: text/plain; charset=utf-8');
    echo "External URL missing.\n";
    exit;
  }

  /* Re-validate against allowlist on every open */
  if (!defined('PRIVATE_PATH') || !is_string(PRIVATE_PATH) || PRIVATE_PATH === '') {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "PRIVATE_PATH missing.\n";
    exit;
  }

  $fn = rtrim(PRIVATE_PATH, '/\\') . '/functions/page_attachments_external.php';
  if (!is_file($fn)) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "External validation function missing.\n";
    exit;
  }
  require_once $fn;

  if (!function_exists('mk_pagefile__validate_external_url')) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "External validator missing.\n";
    exit;
  }

  $v = mk_pagefile__validate_external_url($extUrl);
  if (empty($v['ok']) || empty($v['url'])) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=utf-8');
    mk_staff_audit_try($pdo, 'page_file.download.external_blocked', [
          'file_id' => $fileId,
          'page_id' => $pageId,
          'url'     => $extUrl,
        ]);

    echo "External URL blocked.\n";
    exit;
  }

  $target = str_replace(["\r","\n"], '', (string)$v['url']);
  mk_staff_audit_try($pdo, 'page_file.download.external_redirect', [
      'file_id' => $fileId,
      'page_id' => $pageId,
      'url'     => $target,
    ]);

  header('Location: ' . $target, true, 302);
  exit;
}

/* Local file open */
$storedPath = trim((string)($row['stored_path'] ?? ''));
$filePath   = trim((string)($row['file_path'] ?? ''));

$relative = $storedPath !== '' ? $storedPath : $filePath;
if ($relative === '') {
  http_response_code(400);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Stored path missing.\n";
  exit;
}

/*
  Your uploads live outside /public/:
  /public_html/lib/uploads/page_files/{page_id}/...
*/
$uploadsRoot = dirname(__DIR__, 3) . '/lib/uploads/page_files'; // /public_html/lib/uploads/page_files
$uploadsRootReal = realpath($uploadsRoot);

if (!$uploadsRootReal || !is_dir($uploadsRootReal)) {
  http_response_code(500);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Uploads root missing.\n";
  exit;
}

/* Build absolute path */
$relNorm = str_replace('\\', '/', $relative);
$abs = '';

/* Case 1: stored as web-root relative, e.g. /lib/uploads/page_files/... */
if (strpos($relNorm, '/lib/uploads/page_files/') === 0) {
  $abs = dirname(__DIR__, 3) . $relNorm;
/* Case 2: stored as relative under uploads root */
} elseif ($relNorm !== '' && $relNorm[0] !== '/') {
  $abs = $uploadsRootReal . '/' . ltrim($relNorm, '/\\');
/* Case 3: stored as absolute filesystem path already */
} else {
  $abs = $relNorm;
}

$real = realpath($abs);
if (!$real || !is_file($real)) {
  http_response_code(404);
  header('Content-Type: text/plain; charset=utf-8');
  echo "File missing on disk.\n";
  exit;
}

/* Boundary check: must remain under uploads root */
$rootNorm = rtrim(str_replace('\\','/',$uploadsRootReal), '/');
$realNorm = str_replace('\\','/',$real);
if (strpos($realNorm, $rootNorm . '/') !== 0) {
  http_response_code(403);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Access denied.\n";
  exit;
}

/* Download headers */

$downloadName = trim((string)($row['original_name'] ?? ''));
if ($downloadName === '') $downloadName = basename($real);

$mime = trim((string)($row['mime_type'] ?? ''));
if ($mime === '') $mime = 'application/octet-stream';
mk_staff_audit_try($pdo, 'page_file.download.local_attachment', [
      'file_id' => $fileId,
      'page_id' => $pageId,
      'name'    => $downloadName,
      'mime'    => $mime,
      'bytes'   => (int)@filesize($real),
    ]);

header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header('Content-Disposition: attachment; filename="' . str_replace('"','', $downloadName) . '"');
header('Content-Length: ' . (string)filesize($real));

/* Stream */
$fp = fopen($real, 'rb');
if (!$fp) {
  http_response_code(500);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Failed to read file.\n";
  exit;
}
fpassthru($fp);
fclose($fp);
exit;
