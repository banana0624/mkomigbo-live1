<?php
declare(strict_types=1);

define('STAFF_LOGIN_PAGE', true);

require_once __DIR__ . '/../auth/core.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function h(string $v): string {
    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($email === '' || $pass === '') {
        $error = 'All fields required';
    } else {

        $db = db();

        $stmt = $db->prepare("
            SELECT id, email, password_hash, role 
            FROM staff_users 
            WHERE email = ?
        ");
        $stmt->execute([$email]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($pass, $user['password_hash'])) {

            session_regenerate_id(true);

            // 🔐 UNIFIED AUTH CORE
            auth_login((int)$user['id'], 'staff', [
                'capabilities' => []
            ]);

            header("Location: /staff/");
            exit;

        } else {
            $error = 'Invalid credentials';
        }
    }
}
?>

<h2>Staff Login</h2>

<?php if ($error): ?>
<p style="color:red;"><?= h($error) ?></p>
<?php endif; ?>

<form method="post">
    <input type="email" name="email" placeholder="Email" required>
    <br><br>
    <input type="password" name="password" placeholder="Password" required>
    <br><br>
    <button type="submit">Login</button>
</form>