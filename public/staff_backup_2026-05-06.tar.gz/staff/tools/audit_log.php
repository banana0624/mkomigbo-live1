<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_init.php';

/**
 * /public/staff/tools/audit_log.php
 * Staff Audit Log Viewer (Admin-only)
 *
 * Polished upgrades:
 * - Uses RBAC correctly (mk_require_role('admin')) instead of guessing session role keys
 * - Supports staff_user_id = 0 as “Unauthenticated/Unknown” (filter + quick button)
 * - Better query hygiene: only applies uid filter when explicitly provided (including 0)
 * - Safer rendering for large/invalid JSON (pretty-print best-effort, size clamp)
 * - Convenience quick filters (Denied, Login fails, Logout, Unauth)
 * - Keeps your existing schema: staff_audit_log(id, ts, staff_user_id, event, ip, user_agent, uri, context_json)
 */

if (!ob_get_level()) { @ob_start(); }

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);

// No-cache (this page is sensitive)
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

////////////////////////////////////////////////////////////
// Helpers
////////////////////////////////////////////////////////////
function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }

function mk__pdo_or_null() : ?PDO {
  try {
    if (!function_exists('db')) return null;
    $pdo = db();
    return ($pdo instanceof PDO) ? $pdo : null;
  } catch (Throwable $e) {
    return null;
  }
}

function mk__cap_str(string $s, int $max): string {
  if ($max < 1) return '';
  return (strlen($s) > $max) ? substr($s, 0, $max) : $s;
}

function mk__days_between(string $fromYmd, string $toYmd): int {
  try {
    $a = new DateTimeImmutable($fromYmd);
    $b = new DateTimeImmutable($toYmd);
    return (int)$a->diff($b)->format('%r%a');
  } catch (Throwable $e) {
    return 0;
  }
}

function mk__date_ymd(?string $s): ?string {
  $s = trim((string)$s);
  if ($s === '') return null;
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $s)) return null;
  return $s;
}

function mk__clamp_int($v, int $min, int $max, int $def): int {
  if (!is_numeric($v)) return $def;
  $n = (int)$v;
  if ($n < $min) return $min;
  if ($n > $max) return $max;
  return $n;
}

function mk__pretty_json(?string $json): string {
  $json = (string)$json;
  if (trim($json) === '') return '';

  // Avoid rendering megabytes in <pre>
  if (strlen($json) > 200000) {
    return substr($json, 0, 200000) . "\n\n...[truncated]...";
  }

  $decoded = json_decode($json, true);
  if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
    // Not valid JSON; return raw string (caller escapes)
    return $json;
  }
  $pretty = json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
  return is_string($pretty) && $pretty !== '' ? $pretty : $json;
}

function mk__qs(array $over = []): string {
  $q = $_GET;
  foreach ($over as $k => $v) {
    if ($v === null) unset($q[$k]);
    else $q[$k] = $v;
  }
  $s = http_build_query($q);
  return $s !== '' ? ('?' . $s) : '';
}

////////////////////////////////////////////////////////////
// Ensure auth helpers exist
////////////////////////////////////////////////////////////
if (!function_exists('mk_require_staff_login') || !function_exists('mk_require_role') || !function_exists('mk__session_start')) {
  $auth = null;
  if (defined('PRIVATE_PATH') && is_string(PRIVATE_PATH) && PRIVATE_PATH !== '') {
    $auth = rtrim(PRIVATE_PATH, "/\\") . '/functions/auth.php';
  } elseif (defined('APP_ROOT') && is_string(APP_ROOT) && APP_ROOT !== '') {
    $auth = rtrim(APP_ROOT, "/\\") . '/private/functions/auth.php';
  }
  if ($auth && is_file($auth)) require_once $auth;
}

// Start session using canonical policy when available
if (function_exists('mk__session_start')) {
  mk__session_start();
} else {
}

// Require login + admin role (correct RBAC)
if (function_exists('mk_require_role')) {
  mk_require_role('admin');
} elseif (function_exists('mk_require_staff_login')) {
  auth_require_role('staff');
  // fallback: if RBAC role enforcement isn't available, block hard
  http_response_code(403);
  echo "Forbidden";
  exit;
} else {
  header('Location: /staff/login.php', true, 302);
  exit;
}

// Viewer id (for auditing the view event)
$viewer_id = 0;
if (!empty($_SESSION['staff_user_id']) && is_numeric($_SESSION['staff_user_id'])) $viewer_id = (int)$_SESSION['staff_user_id'];
elseif (!empty($_SESSION['staff_id']) && is_numeric($_SESSION['staff_id'])) $viewer_id = (int)$_SESSION['staff_id'];
elseif (!empty($_SESSION['staff_user']) && is_array($_SESSION['staff_user']) && is_numeric($_SESSION['staff_user']['id'] ?? null)) $viewer_id = (int)$_SESSION['staff_user']['id'];
if ($viewer_id < 0) $viewer_id = 0;

////////////////////////////////////////////////////////////
// DB + filters
////////////////////////////////////////////////////////////
$pdo = mk__pdo_or_null();
if (!$pdo) {
  http_response_code(500);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Audit viewer error: database unavailable.";
  exit;
}

// Defaults: last 7 days
$today        = (new DateTimeImmutable('now'))->format('Y-m-d');
$default_from = (new DateTimeImmutable('now'))->modify('-7 days')->format('Y-m-d');

$event = mk__cap_str(trim((string)($_GET['event'] ?? '')), 64);
$uid_raw   = trim((string)($_GET['staff_user_id'] ?? '')); // IMPORTANT: allow "0"
$uid_set   = ($uid_raw !== '' && is_numeric($uid_raw));
$uid       = $uid_set ? (int)$uid_raw : null; // null means "any"
if ($uid !== null && $uid < 0) $uid = 0;

$date_from = mk__date_ymd($_GET['date_from'] ?? '') ?: $default_from;
$date_to   = mk__date_ymd($_GET['date_to'] ?? '') ?: $today;

$ip       = mk__cap_str(trim((string)($_GET['ip'] ?? '')), 64);
$uri_like = mk__cap_str(trim((string)($_GET['uri'] ?? '')), 255);
$ctx_like = mk__cap_str(trim((string)($_GET['q'] ?? '')), 256);

$page     = mk__clamp_int($_GET['page'] ?? '', 1, 1000000, 1);
$per_page = mk__clamp_int($_GET['per_page'] ?? '', 10, 200, 50);

$order     = strtolower(trim((string)($_GET['order'] ?? 'desc')));
$order_sql = ($order === 'asc') ? 'ASC' : 'DESC';

$offset = ($page - 1) * $per_page;

// Inclusive date bounds
$dt_from = $date_from . ' 00:00:00';
$dt_to   = $date_to   . ' 23:59:59';

$where = [];
$args  = [];

// ts range (required)
$where[]      = "ts BETWEEN :from AND :to";
$args[':from'] = $dt_from;
$args[':to']   = $dt_to;

// event exact match
if ($event !== '') {
  $where[]       = "event = :event";
  $args[':event'] = $event;
}

// staff_user_id exact match (supports 0)
if ($uid_set && $uid !== null) {
  $where[]     = "staff_user_id = :uid";
  $args[':uid'] = $uid;
}

// IP contains
if ($ip !== '') {
  $where[]    = "ip LIKE :ip";
  $args[':ip'] = '%' . $ip . '%';
}

// URI contains
if ($uri_like !== '') {
  $where[]     = "uri LIKE :uri";
  $args[':uri'] = '%' . $uri_like . '%';
}

// context contains
if ($ctx_like !== '') {
  $where[]   = "context_json LIKE :q";
  $args[':q'] = '%' . $ctx_like . '%';
}

$where_sql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

////////////////////////////////////////////////////////////
// Event dropdown (distinct recent)
////////////////////////////////////////////////////////////
$events = [];
try {
  $stEv = $pdo->prepare("
    SELECT DISTINCT event
    FROM staff_audit_log
    WHERE ts >= DATE_SUB(NOW(), INTERVAL 180 DAY)
    ORDER BY event ASC
    LIMIT 500
  ");
  $stEv->execute();
  $events = $stEv->fetchAll(PDO::FETCH_COLUMN) ?: [];
} catch (Throwable $e) {
  $events = [];
}

////////////////////////////////////////////////////////////
// Count + page query
////////////////////////////////////////////////////////////
$total = 0;
$rows = [];
$errMsg = '';

try {
  $stCount = $pdo->prepare("SELECT COUNT(*) FROM staff_audit_log $where_sql");
  foreach ($args as $k => $v) $stCount->bindValue($k, $v);
  $stCount->execute();
  $total = (int)$stCount->fetchColumn();

  $st = $pdo->prepare("
    SELECT id, ts, staff_user_id, event, ip, user_agent, uri, context_json
    FROM staff_audit_log
    $where_sql
    ORDER BY id $order_sql
    LIMIT :lim OFFSET :off
  ");
  foreach ($args as $k => $v) $st->bindValue($k, $v);
  $st->bindValue(':lim', $per_page, PDO::PARAM_INT);
  $st->bindValue(':off', $offset, PDO::PARAM_INT);
  $st->execute();
  $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $rows = [];
  $errMsg = $e->getMessage();
}

////////////////////////////////////////////////////////////
// Audit the view (best-effort) — cooldown to reduce noise
////////////////////////////////////////////////////////////
try {
  $now = time();
  $last = isset($_SESSION['mk_audit_view_ts']) ? (int)$_SESSION['mk_audit_view_ts'] : 0;

  if ($now - $last >= 30) {
    $_SESSION['mk_audit_view_ts'] = $now;

    if (function_exists('mk_staff_audit_log')) {
      mk_staff_audit_log('staff_audit_view', [
        'filters' => [
          'event' => ($event !== '' ? $event : '[any]'),
          'staff_user_id' => ($uid_set ? (string)$uid : '[any]'),
          'date_from' => $date_from,
          'date_to' => $date_to,
          'ip' => ($ip !== '' ? $ip : '[any]'),
          'uri' => ($uri_like !== '' ? $uri_like : '[any]'),
          'q' => ($ctx_like !== '' ? '[set]' : '[empty]'),
        ],
        'page' => $page,
        'per_page' => $per_page,
        'order' => $order_sql,
        'total' => $total,
        'err' => ($errMsg !== '' ? '[db_error]' : ''),
      ], $viewer_id);
    }
  }
} catch (Throwable $e) {
  // swallow
}

$pages = max(1, (int)ceil($total / max(1, $per_page)));

?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Audit Log</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f6f7f9;margin:0;padding:18px}
  .card{max-width:1240px;margin:0 auto;background:#fff;padding:18px;border-radius:14px;box-shadow:0 4px 14px rgba(0,0,0,.08)}
  .top{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap}
  h1{margin:0;font-size:18px}
  a{color:#2563eb;text-decoration:none} a:hover{text-decoration:underline}
  .grid{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-top:14px}
  .grid .full{grid-column:1/-1}
  label{font-size:12px;color:#333}
  input,select{width:100%;padding:9px;margin-top:4px;border:1px solid #cfd4dc;border-radius:10px}
  .btns{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap}
  button{padding:10px 12px;border:none;border-radius:10px;background:#2563eb;color:#fff;font-size:13px;cursor:pointer}
  button.alt{background:#111827}
  .meta{margin-top:12px;color:#555;font-size:13px;display:flex;gap:10px;flex-wrap:wrap;align-items:center}
  table{width:100%;border-collapse:collapse;margin-top:14px}
  th,td{padding:10px;border-bottom:1px solid #eef0f3;vertical-align:top;font-size:13px}
  th{background:#fafafa;text-align:left;font-weight:650}
  .badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#eef2ff;color:#1e3a8a;font-size:12px}
  .pill{display:inline-flex;align-items:center;gap:8px;padding:7px 10px;border:1px solid #e5e7eb;border-radius:999px;background:#fff;font-size:12px;color:#111827}
  code{background:#f0f2f5;padding:2px 6px;border-radius:8px}
  pre{margin:8px 0 0 0;padding:10px;background:#0b1020;color:#e5e7eb;border-radius:12px;overflow:auto;max-height:320px}
  details summary{cursor:pointer;color:#111827}
  .pager{display:flex;gap:10px;align-items:center;justify-content:flex-end;margin-top:12px;flex-wrap:wrap}
  .pager a{padding:6px 10px;border:1px solid #e5e7eb;border-radius:10px;background:#fff}
  .small{font-size:12px;color:#555}
  .hint{font-size:12px;color:#6b7280;margin-top:6px}
  .warn{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}
  @media (max-width: 980px){ .grid{grid-template-columns:repeat(2,1fr)} }
</style>
</head>
<body>

<div class="card">
  <div class="top">
    <div>
      <h1>Staff Audit Log</h1>
      <div class="small">Admin-only • Table: <code>staff_audit_log</code></div>
      <div class="hint">
        Tip: use <code>staff_user_id=0</code> to view unauthenticated/unknown events (e.g. access denied before login).
      </div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
      <a class="pill" href="/staff/">← Staff Home</a>
      <a class="pill" href="/staff/tools/">Tools</a>
      <a class="pill" href="/staff/logout.php">Logout</a>
    </div>
  </div>

  <div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
    <span class="pill">Quick:</span>
    <a class="pill" href="<?=h(mk__qs(['event'=>'staff_access_denied','page'=>1]))?>">Denied</a>
    <a class="pill" href="<?=h(mk__qs(['event'=>'staff_login_failed_password','page'=>1]))?>">Login fail</a>
    <a class="pill" href="<?=h(mk__qs(['event'=>'staff_logout','page'=>1]))?>">Logout</a>
    <a class="pill warn" href="<?=h(mk__qs(['staff_user_id'=>'0','page'=>1]))?>">Unauth (uid=0)</a>
    <a class="pill" href="<?=h(mk__qs([
      'event'=>null,'staff_user_id'=>null,'ip'=>null,'uri'=>null,'q'=>null,'page'=>1
    ]))?>">Clear filters</a>
  </div>

  <form method="get">
    <div class="grid">
      <div>
        <label>Event</label>
        <select name="event">
          <option value="">(any)</option>
          <?php foreach ($events as $ev): ?>
            <?php $sel = ($event === (string)$ev) ? 'selected' : ''; ?>
            <option value="<?=h((string)$ev)?>" <?=$sel?>><?=h((string)$ev)?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div>
        <label>Staff user id</label>
        <input type="number" name="staff_user_id" value="<?=h($uid_set ? (string)$uid : '')?>" placeholder="e.g. 1 (or 0 for unauth)">
        <div class="hint">Leave blank for any • Use <code>0</code> for unauth/unknown</div>
      </div>

      <div>
        <label>Date from</label>
        <input type="date" name="date_from" value="<?=h($date_from)?>">
      </div>

      <div>
        <label>Date to</label>
        <input type="date" name="date_to" value="<?=h($date_to)?>">
      </div>

      <div>
        <label>IP contains</label>
        <input type="text" name="ip" value="<?=h($ip)?>" placeholder="102.143...">
      </div>

      <div>
        <label>URI contains</label>
        <input type="text" name="uri" value="<?=h($uri_like)?>" placeholder="/staff/login.php">
      </div>

      <div class="full">
        <label>Context contains (search in context_json)</label>
        <input type="text" name="q" value="<?=h($ctx_like)?>" placeholder="email, target, role, reason, etc.">
      </div>

      <div>
        <label>Per page</label>
        <select name="per_page">
          <?php foreach ([25,50,100,200] as $pp): ?>
            <?php $sel = ($per_page === $pp) ? 'selected' : ''; ?>
            <option value="<?=h((string)$pp)?>" <?=$sel?>><?=h((string)$pp)?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div>
        <label>Order</label>
        <select name="order">
          <option value="desc" <?=($order_sql==='DESC'?'selected':'')?>>Newest first</option>
          <option value="asc" <?=($order_sql==='ASC'?'selected':'')?>>Oldest first</option>
        </select>
      </div>

      <div class="btns">
        <button type="submit">Filter</button>
        <button class="alt" type="button" onclick="window.location='<?=h(mk__qs([
          'event'=>null,'staff_user_id'=>null,'date_from'=>null,'date_to'=>null,'ip'=>null,'uri'=>null,'q'=>null,'page'=>1
        ]))?>'">Reset</button>
      </div>
    </div>
  </form>

  <div class="meta">
    <span>Total: <span class="badge"><?=h((string)$total)?></span></span>
    <span>• Page <code><?=h((string)$page)?></code> of <code><?=h((string)$pages)?></code></span>
    <span>• Range: <code><?=h($date_from)?></code> → <code><?=h($date_to)?></code></span>
    <?php if ($errMsg !== ''): ?>
      <span class="pill warn">DB warning (hidden): <?=h(substr($errMsg, 0, 120))?><?=strlen($errMsg)>120?'…':''?></span>
    <?php endif; ?>
  </div>
  
  // Prevent inverted range + prevent huge scans
$span = mk__days_between($date_from, $date_to);
if ($span < 0) {
  // swap
  $tmp = $date_from; $date_from = $date_to; $date_to = $tmp;
  $span = -$span;
}
if ($span > 31) {
  // cap to last 31 days ending at date_to
  try {
    $date_from = (new DateTimeImmutable($date_to))->modify('-31 days')->format('Y-m-d');
  } catch (Throwable $e) {
    // keep existing if parsing fails
  }
}

  <table>
    <thead>
      <tr>
        <th style="width:70px">ID</th>
        <th style="width:170px">Timestamp</th>
        <th style="width:120px">Staff ID</th>
        <th style="width:230px">Event</th>
        <th style="width:150px">IP</th>
        <th>URI / Context</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="6" class="small">No rows match your filters.</td></tr>
      <?php else: ?>
        <?php foreach ($rows as $r): ?>
          <?php
            $sid = $r['staff_user_id'] ?? null;
            $sidStr = ($sid === null ? '' : (string)$sid);
            if ($sidStr === '0') $sidStr = '0 (Unauth)';
            if ($sidStr === '') $sidStr = '—';

            $ctxRaw = (string)($r['context_json'] ?? '');
            $ctxPretty = mk__pretty_json($ctxRaw);
            $ev = (string)($r['event'] ?? '');
          ?>
          <tr>
            <td><?=h((string)($r['id'] ?? ''))?></td>
            <td><?=h((string)($r['ts'] ?? ''))?></td>
            <td><?=h($sidStr)?></td>
            <td><span class="badge"><?=h($ev !== '' ? $ev : 'unknown')?></span></td>
            <td><?=h((string)($r['ip'] ?? ''))?></td>
            <td>
              <div><code><?=h((string)($r['uri'] ?? ''))?></code></div>

              <?php if (trim($ctxRaw) !== ''): ?>
                <details>
                  <summary>context_json</summary>
                  <pre><?=h($ctxPretty)?></pre>
                </details>
              <?php endif; ?>

              <?php if (!empty($r['user_agent'])): ?>
                <div class="small" style="margin-top:6px">UA: <?=h((string)$r['user_agent'])?></div>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <div class="pager">
    <?php
      $prev = max(1, $page - 1);
      $next = min($pages, $page + 1);
    ?>
    <span class="small">Navigate:</span>
    <a href="<?=h(mk__qs(['page'=>1]))?>">« First</a>
    <a href="<?=h(mk__qs(['page'=>$prev]))?>">‹ Prev</a>
    <span class="small">Page <?=h((string)$page)?> / <?=h((string)$pages)?></span>
    <a href="<?=h(mk__qs(['page'=>$next]))?>">Next ›</a>
    <a href="<?=h(mk__qs(['page'=>$pages]))?>">Last »</a>
  </div>
</div>

</body>
</html>