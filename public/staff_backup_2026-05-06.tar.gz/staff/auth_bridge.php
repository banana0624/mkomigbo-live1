<?php
require_once __DIR__ . "/../auth/core.php";

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function mk_attempt_staff_login($email, $password)
{
    $pdo = db();

    $stmt = $pdo->prepare("SELECT * FROM staff_users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !$user['is_active']) {
        return false;
    }

    if (!password_verify($password, $user['password_hash'])) {
        return false;
    }

    $_SESSION['staff_user_id'] = $user['id'];
    $_SESSION['staff_role'] = $user['role'] ?? 'staff';

    return true;
}

function auth_require_role('staff')
{
    if (empty($_SESSION['staff_user_id'])) {
        header("Location: /staff/login.php");
        exit;
    }
}