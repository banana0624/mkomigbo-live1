<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_init.php';
auth_require_role('staff');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (!function_exists('redirect_to')) {
  function redirect_to(string $location): void {
    $location = str_replace(["\r","\n"], '', trim($location));
    if ($location === '') $location = '/staff/contributors/index.php';
    if ($location[0] === '/') {
      header('Location: ' . $location, true, 302);
      exit;
    }
    if (function_exists('url_for')) {
      $location = (string)url_for($location);
    }
    header('Location: ' . $location, true, 302);
    exit;
  }
}
if (!function_exists('flash_set')) {
  function flash_set(string $key, string $msg): void {
    if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) $_SESSION['flash'] = [];
    $_SESSION['flash'][$key] = $msg;
  }
}
if (!function_exists('safe_return')) {
  function safe_return(string $raw, string $default): string {
    $raw = trim($raw);
    if ($raw === '') return $default;
    $raw = rawurldecode($raw);
    if ($raw === '' || $raw[0] !== '/') return $default;
    if (preg_match('~^//~', $raw)) return $default;
    if (preg_match('~^[a-z]+:~i', $raw)) return $default;
    if (!preg_match('~^/staff/~', $raw)) return $default;
    return $raw;
  }
}
if (!function_exists('table_exists')) {
  function table_exists(PDO $pdo, string $table): bool {
    $st = $pdo->prepare("SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1");
    $st->execute([$table]);
    return (bool)$st->fetchColumn();
  }
}
if (!function_exists('column_exists')) {
  function column_exists(PDO $pdo, string $table, string $column): bool {
    $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
    $st->execute([$table, $column]);
    return ((int)$st->fetchColumn() > 0);
  }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  redirect_to('/staff/contributors/index.php');
}

$token = (string)($_POST['csrf_token'] ?? '');
$sess  = (string)($_SESSION['csrf_token'] ?? '');
if ($token === '' || $sess === '' || !hash_equals($sess, $token)) {
  http_response_code(403);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Invalid CSRF token.";
  exit;
}

$return = safe_return((string)($_POST['return'] ?? '/staff/contributors/index.php'), '/staff/contributors/index.php');

$action = trim((string)($_POST['action'] ?? ''));
$map = [
  'publish'     => 'set_active',
  'unpublish'   => 'set_draft',
  'delete'      => 'soft_delete',
  'set_active'  => 'set_active',
  'set_draft'   => 'set_draft',
  'set_public'  => 'set_public',
  'set_private' => 'set_private',
  'soft_delete' => 'soft_delete',
  'restore'     => 'restore',
];
$action = $map[$action] ?? '';

if ($action === '') {
  flash_set('error', 'Invalid bulk action.');
  redirect_to($return);
}

$ids_in = $_POST['ids'] ?? [];
$ids = [];
if (is_array($ids_in)) {
  foreach ($ids_in as $v) {
    $n = (int)$v;
    if ($n > 0) $ids[] = $n;
  }
}
$ids = array_values(array_unique($ids));

if (!$ids) {
  flash_set('error', 'No valid contributor rows selected.');
  redirect_to($return);
}

$pdo = function_exists('staff_pdo') ? staff_pdo() : db();
if (!$pdo instanceof PDO) {
  flash_set('error', 'Database handle not available.');
  redirect_to($return);
}
if (!table_exists($pdo, 'contributors')) {
  flash_set('error', 'contributors table not found.');
  redirect_to($return);
}

$has_status    = column_exists($pdo, 'contributors', 'status');
$has_public    = column_exists($pdo, 'contributors', 'is_public');
$has_deleted   = column_exists($pdo, 'contributors', 'deleted_at');
$has_updated   = column_exists($pdo, 'contributors', 'updated_at');

$in = implode(',', array_fill(0, count($ids), '?'));

try {
  switch ($action) {
    case 'set_active':
      if (!$has_status) {
        flash_set('error', 'contributors.status column is missing.');
        redirect_to($return);
      }
      $sql = "UPDATE contributors SET status = 'active'";
      if ($has_deleted) $sql .= ", deleted_at = NULL";
      if ($has_updated) $sql .= ", updated_at = NOW()";
      $sql .= " WHERE id IN ($in)";
      $msg = 'Contributor(s) set active.';
      break;

    case 'set_draft':
      if (!$has_status) {
        flash_set('error', 'contributors.status column is missing.');
        redirect_to($return);
      }
      $sql = "UPDATE contributors SET status = 'draft'";
      if ($has_updated) $sql .= ", updated_at = NOW()";
      $sql .= " WHERE id IN ($in)";
      $msg = 'Contributor(s) set draft.';
      break;

    case 'set_public':
      if (!$has_public) {
        flash_set('error', 'contributors.is_public column is missing.');
        redirect_to($return);
      }
      $sql = "UPDATE contributors SET is_public = 1";
      if ($has_updated) $sql .= ", updated_at = NOW()";
      $sql .= " WHERE id IN ($in)";
      $msg = 'Contributor(s) set public.';
      break;

    case 'set_private':
      if (!$has_public) {
        flash_set('error', 'contributors.is_public column is missing.');
        redirect_to($return);
      }
      $sql = "UPDATE contributors SET is_public = 0";
      if ($has_updated) $sql .= ", updated_at = NOW()";
      $sql .= " WHERE id IN ($in)";
      $msg = 'Contributor(s) set private.';
      break;

    case 'soft_delete':
      if (!$has_deleted) {
        flash_set('error', 'contributors.deleted_at column is missing.');
        redirect_to($return);
      }
      $sets = ["deleted_at = NOW()"];
      if ($has_status) $sets[] = "status = 'draft'";
      if ($has_public) $sets[] = "is_public = 0";
      if ($has_updated) $sets[] = "updated_at = NOW()";
      $sql = "UPDATE contributors SET " . implode(', ', $sets) . " WHERE id IN ($in) AND deleted_at IS NULL";
      $msg = 'Contributor(s) moved to trash.';
      break;

    case 'restore':
      if (!$has_deleted) {
        flash_set('error', 'contributors.deleted_at column is missing.');
        redirect_to($return);
      }
      $sets = ["deleted_at = NULL"];
      if ($has_updated) $sets[] = "updated_at = NOW()";
      $sql = "UPDATE contributors SET " . implode(', ', $sets) . " WHERE id IN ($in)";
      $msg = 'Contributor(s) restored.';
      break;

    default:
      flash_set('error', 'Unsupported bulk action.');
      redirect_to($return);
  }

  $st = $pdo->prepare($sql);
  $st->execute($ids);

  flash_set('notice', $msg);
  redirect_to($return);

} catch (Throwable $e) {
  flash_set('error', 'Bulk action failed: ' . $e->getMessage());
  redirect_to($return);
}
