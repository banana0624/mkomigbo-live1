<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_init.php';
auth_require_role('staff');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (!function_exists('redirect_to')) {
  function redirect_to(string $location): void {
    $location = str_replace(["\r","\n"], '', $location);
    header('Location: ' . $location, true, 302);
    exit;
  }
}
if (!function_exists('flash_set')) {
  function flash_set(string $key, string $msg): void {
    if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) $_SESSION['flash'] = [];
    $_SESSION['flash'][$key] = $msg;
  }
}
if (!function_exists('safe_return')) {
  function safe_return(string $raw, string $default): string {
    $raw = trim($raw);
    if ($raw === '') return $default;
    $raw = rawurldecode($raw);
    if ($raw === '' || $raw[0] !== '/') return $default;
    if (preg_match('~^//~', $raw)) return $default;
    if (preg_match('~^[a-z]+:~i', $raw)) return $default;
    if (!preg_match('~^/staff/~', $raw)) return $default;
    return $raw;
  }
}
if (!function_exists('normalize_roles')) {
  function normalize_roles(string $raw): array {
    $raw = trim($raw);
    if ($raw === '') return ['ok' => true, 'value' => '[]'];

    if (isset($raw[0]) && $raw[0] === '[') {
      $decoded = json_decode($raw, true);
      if (!is_array($decoded)) {
        return ['ok'=>false,'value'=>'','error'=>'Roles JSON is invalid.'];
      }
      $out = [];
      foreach ($decoded as $v) {
        $v = trim((string)$v);
        if ($v !== '') $out[] = $v;
      }
      $out = array_values(array_unique($out));
      return ['ok'=>true,'value'=>json_encode($out, JSON_UNESCAPED_UNICODE)];
    }

    $parts = preg_split('/\s*,\s*/', $raw) ?: [];
    $out = [];
    foreach ($parts as $p) {
      $p = trim((string)$p);
      if ($p !== '') $out[] = $p;
    }
    $out = array_values(array_unique($out));
    return ['ok'=>true,'value'=>json_encode($out, JSON_UNESCAPED_UNICODE)];
  }
}
if (!function_exists('safe_bio_html')) {
  function safe_bio_html(string $raw): string {
    $raw = trim($raw);
    if ($raw === '') return '';
    return nl2br(htmlspecialchars($raw, ENT_QUOTES, 'UTF-8'), false);
  }
}
if (!function_exists('mk_slugify_local')) {
  function mk_slugify_local(string $raw, string $fallback = 'contributor'): string {
    $raw = trim($raw);
    if ($raw === '') return $fallback;
    $raw = strtolower($raw);
    $raw = preg_replace('/[^a-z0-9]+/i', '-', $raw) ?? $raw;
    $raw = trim($raw, '-');
    return $raw !== '' ? $raw : $fallback;
  }
}
if (!function_exists('mk_unique_contributor_slug')) {
  function mk_unique_contributor_slug(PDO $pdo, string $base, ?int $excludeId = null): string {
    $base = trim($base);
    if ($base === '') $base = 'contributor';
    $slug = $base;

    for ($i = 0; $i < 50; $i++) {
      $sql = "SELECT id FROM contributors WHERE slug = ?";
      $params = [$slug];
      if ($excludeId !== null) {
        $sql .= " AND id <> ?";
        $params[] = $excludeId;
      }
      $sql .= " LIMIT 1";

      $st = $pdo->prepare($sql);
      $st->execute($params);
      if (!$st->fetch(PDO::FETCH_ASSOC)) return $slug;

      $slug = $base . '-' . ($i + 2);
    }

    return $base . '-' . time();
  }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  header('Allow: POST');
  echo "Method Not Allowed";
  exit;
}

$token = (string)($_POST['csrf_token'] ?? '');
$sess  = (string)($_SESSION['csrf_token'] ?? '');
if ($token === '' || $sess === '' || !hash_equals($sess, $token)) {
  http_response_code(403);
  echo "Invalid CSRF token.";
  exit;
}

$id           = (int)($_POST['id'] ?? 0);
$return       = safe_return((string)($_POST['return'] ?? '/staff/contributors/index.php'), '/staff/contributors/index.php');
$display_name = trim((string)($_POST['display_name'] ?? ''));
$slug_raw     = trim((string)($_POST['slug'] ?? ''));
$email        = trim((string)($_POST['email'] ?? ''));
$roles_raw    = trim((string)($_POST['roles'] ?? ''));
$status       = trim((string)($_POST['status'] ?? 'active'));
$is_public    = ((string)($_POST['is_public'] ?? '1') === '1') ? 1 : 0;
$sort_order   = (int)($_POST['sort_order'] ?? 0);
$bio_raw      = trim((string)($_POST['bio_raw'] ?? ''));

if ($id <= 0) {
  flash_set('error', 'Invalid contributor ID.');
  redirect_to($return);
}
if ($display_name === '') {
  flash_set('error', 'Display name is required.');
  redirect_to($return);
}
if (!in_array($status, ['active', 'draft'], true)) {
  $status = 'draft';
}

$roles = normalize_roles($roles_raw);
if (empty($roles['ok'])) {
  flash_set('error', (string)$roles['error']);
  redirect_to($return);
}

$pdo = db();

try {
  $slug_base = mk_slugify_local($slug_raw !== '' ? $slug_raw : $display_name, 'contributor');
  $slug = mk_unique_contributor_slug($pdo, $slug_base, $id);
  $bio_html = safe_bio_html($bio_raw);

  $st = $pdo->prepare("
    UPDATE contributors
       SET slug = ?,
           display_name = ?,
           email = ?,
           roles = ?,
           status = ?,
           is_public = ?,
           sort_order = ?,
           bio_raw = ?,
           bio_html = ?,
           updated_at = NOW()
     WHERE id = ?
     LIMIT 1
  ");
  $st->execute([
    $slug,
    $display_name,
    ($email !== '' ? $email : null),
    (string)$roles['value'],
    $status,
    $is_public,
    $sort_order,
    ($bio_raw !== '' ? $bio_raw : null),
    ($bio_html !== '' ? $bio_html : null),
    $id,
  ]);

  flash_set('notice', 'Contributor updated successfully.');
  redirect_to('/staff/contributors/index.php');

} catch (Throwable $e) {
  flash_set('error', 'Update failed: ' . $e->getMessage());
  redirect_to($return);
}