<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_init.php';
auth_require_role('staff');

/**
 * Staff: Platforms
 * Canonical bootstrap + auth gate
 */

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (!function_exists('h')) {
  function h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
  }
}

if (!function_exists('redirect_to')) {
  function redirect_to(string $location): void {
    $location = str_replace(["\r", "\n"], '', $location);
    header('Location: ' . $location, true, 302);
    exit;
  }
}

if (!function_exists('pf__u')) {
  function pf__u(string $path): string {
    return function_exists('url_for') ? url_for($path) : $path;
  }
}

/**
 * /public/platforms/_platform_template.php
 *
 * Standard platform page template (single source of truth).
 *
 * Goals:
 * - Ensure every platform page sets a correct <title> and meta description
 * - Keep canonical/og:url correct (public_header already does)
 * - Use shared public_header.php / public_footer.php only
 *
 * Expected variables (set by controller BEFORE include):
 * - $platform_key   (string) slug, e.g. "blog", "forum", "gallery"
 * - $platform_label (string) human label, e.g. "Blog", "Forum", "Gallery"
 * - $platform_desc  (string) optional; if empty, defaults are used
 * - $platform_body_html (string) optional; if set, template prints it
 *
 * Optional:
 * - $breadcrumbs (array) of [href,label] items (optional)
 */

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);

require_once __DIR__ . '/_init.php';

if (!function_exists('h')) {
  function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
}

$norm = static function($s): string {
  $s = is_string($s) ? $s : (string)$s;
  $s = trim($s);
  if ($s === '') return '';
  $s = preg_replace('/\s+/u', ' ', $s) ?? $s;
  return trim($s);
};

/* ---------------------------------------------------------
   Platform defaults (edit freely)
--------------------------------------------------------- */
$defaults = [
  'blog'            => ['Blog', 'Articles and long-form writing from Mkomigbo.'],
  'communities'     => ['Communities', 'Community hubs, groups, and participation spaces.'],
  'forum'           => ['Forum', 'Discussion boards for questions, debates, and knowledge exchange.'],
  'gallery'         => ['Gallery', 'Curated images and visual collections related to Igbo knowledge.'],
  'knowledge-index' => ['Knowledge Index', 'Browsable index of topics, sources, and structured entries.'],
  'media-library'   => ['Media Library', 'Audio, video, images, and documents — organized and searchable.'],
  'podcast'         => ['Podcast', 'Audio episodes: interviews, discussions, and deep dives.'],
  'posts'           => ['Posts', 'Short updates and quick publishing format.'],
  'reel'            => ['Reel', 'Short-form videos and highlights.'],
  'threads'         => ['Threads', 'Threaded posts and ongoing conversations.'],
  'vlog'            => ['Vlog', 'Video logs and recorded explanations.'],
  'igbo-calendar'   => ['Igbo Calendar', 'The Igbo calendar app and related tools.'],
];

/* ---------------------------------------------------------
   Inputs
--------------------------------------------------------- */
$platform_key   = isset($platform_key) ? $norm($platform_key) : '';
$platform_label = isset($platform_label) ? $norm($platform_label) : '';
$platform_desc  = isset($platform_desc) ? $norm($platform_desc) : '';

if ($platform_key === '') {
  // Try infer from URI: /platforms/{slug}/
  $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
  if (preg_match('~^/platforms/([^/]+)/~', $uri, $m)) {
    $platform_key = $norm($m[1]);
  }
}

if ($platform_key !== '' && isset($defaults[$platform_key])) {
  if ($platform_label === '') $platform_label = $defaults[$platform_key][0];
  if ($platform_desc === '')  $platform_desc  = $defaults[$platform_key][1];
}

if ($platform_label === '') $platform_label = 'Platforms';
if ($platform_desc === '')  $platform_desc  = 'Mkomigbo platforms and publishing channels.';

/* ---------------------------------------------------------
   SEO + header
--------------------------------------------------------- */
$nav_active = 'platforms';

$page_title = $platform_label . ' — Platforms';
$page_desc  = $platform_desc;

// Controller-level SEO contract (header honors this)
$GLOBALS['seo'] = array_merge((isset($GLOBALS['seo']) && is_array($GLOBALS['seo'])) ? $GLOBALS['seo'] : [], [
  'title'       => $page_title,
  'description' => $page_desc,
]);

// Render shared header
$ok = false;
try { mk_require_shared('public_header.php'); $ok = true; } catch (Throwable $e) {}
if (!$ok) {
  header('Content-Type: text/plain; charset=utf-8');
  echo "Header include failed.\n";
  exit;
}

/* ---------------------------------------------------------
   Breadcrumbs
--------------------------------------------------------- */
$crumbs = [];
$crumbs[] = ['/', 'Home'];
$crumbs[] = ['/platforms/', 'Platforms'];
if ($platform_key !== '' && $platform_label !== 'Platforms') {
  $crumbs[] = ['/platforms/' . rawurlencode($platform_key) . '/', $platform_label];
}
if (isset($breadcrumbs) && is_array($breadcrumbs)) {
  // allow controller to override/add
  $crumbs = $breadcrumbs;
}

/* ---------------------------------------------------------
   Page shell open
--------------------------------------------------------- */
?>
<main class="container mk-page">
  <nav class="mk-crumbs" aria-label="Breadcrumb">
    <?php
      $last = count($crumbs) - 1;
      foreach ($crumbs as $i => $c) {
        $href = (string)($c[0] ?? '#');
        $lab  = (string)($c[1] ?? '');
        if ($i > 0) echo '<span class="mk-crumbs__sep">›</span>';
        if ($i === $last) {
          echo '<span class="mk-crumbs__current">' . h($lab) . '</span>';
        } else {
          echo '<a href="' . h($href) . '">' . h($lab) . '</a>';
        }
      }
    ?>
  </nav>

  <header class="mk-hero mk-hero--compact">
    <div class="mk-hero__bar" aria-hidden="true"></div>
    <div class="mk-hero__inner">
      <h1 class="mk-hero__title"><?= h($platform_label) ?></h1>
      <p class="mk-hero__subtitle"><?= h($platform_desc) ?></p>
    </div>
  </header>

  <?php
  // Optional body HTML slot
  if (isset($platform_body_html) && is_string($platform_body_html) && trim($platform_body_html) !== '') {
    echo $platform_body_html;
  }
  ?>
</main>

<?php
// Render shared footer
try { mk_require_shared('public_footer.php'); } catch (Throwable $e) {}
