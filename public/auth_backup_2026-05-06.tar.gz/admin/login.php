<?php
declare(strict_types=1);

require_once __DIR__ . '/../../auth/core.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$db = db();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'All fields are required';
    } else {

        $stmt = $db->prepare("
            SELECT id, email, password_hash, role 
            FROM staff_users 
            WHERE email = ?
        ");
        $stmt->execute([$email]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password_hash'])) {

            session_regenerate_id(true);

            // 🔐 UNIFIED AUTH CORE
            auth_login((int)$user['id'], 'admin', [
                'capabilities' => []
            ]);

            header("Location: /admin/dashboard");
            exit;

        } else {
            $error = 'Invalid credentials';
        }
    }
}
?>

<!doctype html>
<html>
<head>
    <title>Admin Login</title>

    <style>
        body { font-family: Arial, sans-serif; background:#f4f6f8; margin:20px; }
        h2 { margin-bottom:10px; }
        input, button { padding:8px; margin:5px 0; }
        button { cursor:pointer; }
        .error { color:red; }
    </style>
</head>
<body>

<h2>Admin Login</h2>

<?php if ($error): ?>
<p class="error"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<form method="post">
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Login</button>
</form>

</body>
</html>