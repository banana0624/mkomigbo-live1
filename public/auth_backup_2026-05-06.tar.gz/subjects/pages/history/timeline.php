<?php
declare(strict_types=1);

return [
  'title' => 'Timeline',
  'body_html' => <<<MKHTML_7bb92116
<div class="mk-prose">

  <p class="mk-muted" style="margin-top:0;">
    <strong>Subject</strong> — Overview.
    Starter scaffold: readable now, expandable later.
  </p>

  <div style="display:flex; gap:10px; flex-wrap:wrap; margin:10px 0 14px;">
          <a class="mk-btn mk-btn--ghost"
         href="/subjects//intro/">
        Introduction      </a>
          <a class="mk-btn mk-btn--ghost"
         href="/subjects//overview/">
        Overview      </a>
          <a class="mk-btn mk-btn--ghost"
         href="/subjects//topics/">
        Key Topics      </a>
          <a class="mk-btn mk-btn--ghost"
         href="/subjects//people/">
        People      </a>
          <a class="mk-btn mk-btn--ghost"
         href="/subjects//sources/">
        Sources      </a>
      </div>

  <h2>What belongs here</h2>
  <ul>
    <li><strong>Scope:</strong> what this page covers and excludes.</li>
    <li><strong>Key points:</strong> the essentials readers should remember.</li>
    <li><strong>Structure:</strong> sections you’ll expand later.</li>
  </ul>

  <hr>

  <p class="mk-muted">
    Tip: add citations and attach source links/files below.
  </p>

</div>
MKHTML_7bb92116,
];
